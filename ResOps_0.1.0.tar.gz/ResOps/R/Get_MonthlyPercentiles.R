#' Get monthly Percentiles
#'
#'Calculates the monthly percentiles for a matrix of monthly values give a range of years

#' @param  monthly.data a matrix of values where the first column is the year and the next 12 columns are monthly values for that year.
#' @param  percentile.list A vector of the percentile values to be calcualted.
#' @param  year.range The range of years from the original input data that should be used for calculation (firstyear, last year).
#' NOTE: If the beginning of the range is before the first year of the data it will default to starting with the first year of data and similarly if the
#' last year is after the end of the data it will default to the last year available.
#' @return a matrix of the percentile values with 12 columns (one for each month) and a row for each percentile value given in percentile.list
#'
#' @examples
#' get.monthlypctl(monthlydata=monthmatrix, percentile.list=c(0.25, 0.5, 0.75), year.rang3=c(1950, 2000))
#'
#' @export
#'

get.monthlypctl=function(monthlydata, percentile.list, year.range){
  #get starting and ending years
  year.start=year.range[1]
  year.end=year.range[2]

  #find the rows these correspond to in the monthly mat
  istart = which(monthlydata[,1]==year.start)
  iend = which(monthlydata[,1]==year.end)

  #Adjust the start/end dates if necessary given the range of the data
  if(length(istart)==0){
    print(paste("WARNING: Starting year is before the start of the dataset, changing start year to ", monthlydata[1,1]))
    istart=1
  }

  if(length(iend)==0){
    print(paste("WARNING: Ending year is after the end of the dataset, changing end year to ", monthlydata[nrow(monthlydata),1]))
    iend=nrow(monthlydata)
  }

  #clip the data for the year range of interest
  dataclip=monthlydata[istart:iend,]
  #calculate the percentiles
  pctl_mat=apply(dataclip[,-1],2,quantile, percentile.list, na.rm=T)

  return(pctl_mat)
} # end function





#inputs -Matrix of monthly values
# year range you want to consider

# Storage percentiles
# Outflow percentiles
# Date range to use
# Need a good way to remove NA's
# Output
# Matrix with storage probabilites by month
# Matrix with flow probabilities by month


# qcl, qc, qcu, qnl, qn, qnu, qml, qm, qmu
# c  =, n=ormal? m=
# l= lowerbound, u=upper bound
#th=c(5, 10, 35, 45, 75,	85,	95)
#  what I need



#Step 1 tingle  columns of  dates, inflow and outflow for a  period of interest
#res_info_out.timed   = timed2;
#res_info_out.stoobs  = resdata(k1:k2,4).*1000000;                            % converts volume unit from Mm3 to m3 (col 4 is storage)
#res_info_out.inflow  = resdata(k1:k2,5);                                     % col 5 is inflow   (m3/s)
#res_info_out.outflow = resdata(k1:k2,6);                                     % col 6 is outflow  (m3/s)

#Step 0- setting thresholds for opearting  policies
#par_sel_release = [10,45,85,5,35,75,35,75,95];                               % percentile for qc, qn, qm, qcl, qnl, qml, qcu, qnu, qmu
#par_sel_storage = [10,45,85,5,35,75,35,75,95];                               % percentile for sc, sn, sm, scl, snl, sml, scu, snu, smu

#  I think  this just gets  percentiles  of inflow, outflow  and  storage
#onan=~isnan(res_info_out.outflow); inan=~isnan(res_info_out.inflow);  snan=~isnan(res_info_out.stoobs);  % to index out missing values
#fdurn  =dztr_param(res_info_out.outflow(onan,1),'MonthPartition',res_info_out.timed(onan,1));            % release monthly percentile
#indurn =dztr_param(res_info_out.inflow(inan,1),'MonthPartition',res_info_out.timed(inan,1));             % inflow monthly percentile (non required)
#sdurn  =dztr_param(res_info_out.stoobs(snan,1),'MonthPartition',res_info_out.timed(snan,1));             % storge monthly percentile

#Reservoir parameters
# Storage parameters (First 3 rows,  12  columns)
# Row  1 =  10th percentile storage - ("sc monthly no-exe value)
# Row  2 = 45th percentile storage - ("sn monthly non-exe value)
# Row  3 = 85th percentile storage ("sm  monthly non-exe  value)
#% default parameters for storage. row 1 sc monthly non-exe value, row 2 sn monthly non-exe value, row 3 sm monthly non-exe value
#for i=1:3
#respar(i,:) = sdurn.percentiles((sdurn.percentiles(:,1)==par_sel_storage(i)),3:14);
#end

# Outflow parameters (Rows 4-6,  12  columns)
# Row  1 =  10th percentile storage - ("qc monthly no-exe value)
# Row  2 = 45th percentile storage - ("qn monthly non-exe value)
# Row  3 = 85th percentile storage ("qm  monthly non-exe  value)
#% default parameters for release. row 4 qc monthly non-exe value, row 5 qn monthly non-exe value, row 6 qm monthly non-exe value
#for i=4:6
#respar(i,:) = fdurn.percentiles((fdurn.percentiles(:,1)==par_sel_release(i-3)),3:14);    % storage 1 value
#end

# Outflow parameters (Rows 4-6,  12  columns)
# Row  1 =  10th percentile storage - ("qc monthly no-exe value)
# Row  2 = 45th percentile storage - ("qn monthly non-exe value)
# Row  3 = 85th percentile storage ("qm  monthly non-exe  value)
#% release monthly lower and upper bound non-exe value from row 7 to row 12
#% row order (qcl, qnl, qml, qcu, qnu, qmu)
#for i=7:12
#respar(i,:) = fdurn.percentiles((fdurn.percentiles(:,1)==par_sel_release(i-3)),3:14);    % storage 1 value
#end

#% storage monthly lower and upper bound non-exe value from row 13 to row 18
#% row order (scl, snl, sml, scu, snu, smu)
#for i=13:18
#respar(i,:) = sdurn.percentiles((sdurn.percentiles(:,1)==par_sel_storage(i-9)),3:14);    % storage 1 value
#end
