#' Test function
#' This function does something
#' @param x your variable
#' @export
#'
myfun <- function(x){x + 7}

myfun2<- function(x){x +2}
